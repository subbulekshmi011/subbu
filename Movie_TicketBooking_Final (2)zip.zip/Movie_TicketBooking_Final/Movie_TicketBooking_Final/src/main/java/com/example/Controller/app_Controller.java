package com.example.Controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.seat_booking_detailes;
import com.example.model.users;
import com.example.repo.UserInterFace;
import com.example.repo.seatBookingRepo;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;


@Controller
@Service
public class app_Controller extends HttpServlet {

	private static final long serialVersionUID = 1L;
	@Autowired
	UserInterFace service;
	@Autowired
	private users user;

	@GetMapping("/index")
	public String home() {
		return "registerform";

	}

	@PostMapping("/Register")
	public String Regiter(HttpServletRequest req) {
		///////////////////////////////////////////////
		
		/////////////////////
		String Name = req.getParameter("name");
		String mobile1 = req.getParameter("mobile");
		// parse bigInteger
		BigInteger mobile = new BigInteger(mobile1);
		String Email = req.getParameter("email");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		//System.out.println("Name :" + Name + " Mobile No :" + mobile + " Email :" + Email + " UserName :" + username
		//		+ " Password :" + password);
		user.setEmail(Email);
		user.setMobile(mobile);
		user.setName(Name);
		user.setUserName(username);
		user.setPassword(password);
		save_user(user);
		//***** ints very very importent
		user=new users();
		//
		return "login";
		
	}
		
	

	//save method
	@Transactional
	private void save_user(users user) {
		service.save(user);
		
		
	}

	@PostMapping("/login")
	public String Login(HttpServletRequest req) {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		System.out.println("Username :" + username + "\n password :" + password);

		FindAllUsernameAndPassword();
		// importent Logic
		for (users user : FindAllUsernameAndPassword()) {
			System.out.println("DBUsername: " + user.getUserName() + "		DBPassword: " + user.getPassword());
			if (username.equals(user.getUserName())) {
				if (password.equals(user.getPassword())) {
					System.out.println("Curect>>>>>>>>>>>>>>>>>>>>");
					return "home";
				}
			}
		}
		System.out.println("wrong>>>>>>>>>>>>>>>>>>>>");
		return "FailLogin";
	}

	// FindAllUsernameAndPassword
	public List<users> FindAllUsernameAndPassword() {
		List<users> allUserAndPass = service.findAll();
		return allUserAndPass;
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/privecy")
	public String privacyPolicy() {
		return "Privecy";
	}

	@GetMapping("/terms")
	public String Terms() {
		return "TermsAndConditions";
	}

	@GetMapping("/FAQ")
	public String FAQ() {
		return "FAQ";
	}

	@GetMapping("/movies")
	public String movies() {
		return "movies";
	}

	// Decler movie details functions object

	// Movie Deatiles Logics It is vary vary importent
	@GetMapping("/movie-details.html")
	public String movieInfo(HttpServletRequest req) {
		String movie = req.getParameter("movie");
		switch (movie) {
		case "legent":
			return "legentDTLS";

		case "naaisekar":
			return "naaisekarDTLS";

		case "merasal":
			return "merasalDTLS";
		}
		return null;
	}

	@GetMapping("/showTime")
	public String showTimes() {
		return "showTiming";

	}

	@GetMapping("/Bookings")
	public String Booking(Model m) {
		//sdfsd
		List<seat_booking_detailes> AllBookings=(List<seat_booking_detailes>)Service.findAll();
		
		for (seat_booking_detailes item : AllBookings) {
		    System.out.println(item.getId()+" ,"+item.getDate()+" , "+item.getTime()+
		    		" , "+item.getMovie_Name()+
		    		" ," +item.getSeatts()+" ,"+item.getMobile()+" ,"+item.getName() );
		}

		m.addAttribute("AllBooking", AllBookings);
		return "BookingHistory";

	}


	@GetMapping("/contectUs")
	public String ContectUs() {
		return "contectUs";

	}

	@GetMapping("/BookNow")
	public String BookNow() {
		return "booking";
	}

	@Autowired
	seatBookingRepo Service;

	@Autowired
	private seat_booking_detailes BDTLS;
	
	//
	
	
	private String movieName;
	private String time;
	private String date;
	private String bookingUserName;
	private String bookingUserEmail;
	private  String bookingUserMobile;
	private BigInteger mobileNumber;
	
	@GetMapping("/BookingDTLS")
	public String BookingDTLS(HttpServletRequest req, Model m) {
		 movieName = req.getParameter("movie");
		 time = req.getParameter("showtime");
		 date = req.getParameter("show-date");
		 bookingUserName = req.getParameter("name");
		 bookingUserEmail = req.getParameter("email");
		 bookingUserMobile = req.getParameter("phone");
		 mobileNumber = new BigInteger(bookingUserMobile);

		
		//System.out.println("DATAS ARE SAVED >>>>>>>>>>");
		System.out.println("Movie name: " + movieName + "\nTime: " + time + "\nDate: " + date + "\nBooking User Name: "
				+ bookingUserName + "\nBooking User Email: " + bookingUserEmail + "\nBooking User Mobile: "
				+ bookingUserMobile);
		
		//
		List<seat_booking_detailes> AllBookings=(List<seat_booking_detailes>)Service.findAll();
			
		importent_Methods sa=new importent_Methods();
		
		//***impotent
		
		List<seat_booking_detailes> ans1=sa.getSameBookings(movieName, date, time, AllBookings);
			
		if(ans1!=null) {
				String[] arr=new String[50];
				
				int a=1;	
				int ansarrLength=0;
			for(seat_booking_detailes item :ans1) {				
					//
				System.out.println("movie : "+item.getMovie_Name()+" Date :"+item.getDate() +" time :"+item.getTime()+".........seats :"+item.getSeatts());
				arr[a]=item.getSeatts();
				System.out.println(arr[a]);
				ansarrLength++;
						a++;
			}
			a=1;//madsgrterdfd
			
			//array length
			int arrLen= arr.length;
			System.out.println(arrLen);
			
			// creat ansarray
			String[] ansarr=new String[50];
			int sizeAnsarray=ansarr.length-1;
			int one=1;
			
			
				//itrate and add values for ansarray
			
			for(one=1;one<=sizeAnsarray;one++) {
				int g=1;
				if(arr[one]!=null){
					ansarr[g]=arr[one];
					System.out.println("erttretertrtre :"+ansarr[g]);
					g++;
					
				}	
			}
		
			//itreate values
			
			for(int y=1;y<=ansarr.length-1;y++) {
				if(ansarr[y]!=null) {
				System.out.println("erttretertrtre123 :"+ansarr[y]);
					
		    
		
				}			 
				// ansarr array is redy......					
			}
			System.out.println("lengthOfAnsarr :"+ansarrLength);
			//finised .....dot tuch this
			
			
			String MainMasilaAnswer_is =Arrays.stream(arr) 
            .filter(s -> s != null) // Remove nulls
            .collect(Collectors.joining(", ")); 
			
			//Finished ++++++++++++++
			if(MainMasilaAnswer_is!=null) {
				System.out.println("ansString is ********************** :"+MainMasilaAnswer_is);
				// Convert to an array or list
		        List<String> bookedSeatList = Arrays.asList(MainMasilaAnswer_is.split(","));
				m.addAttribute("UnAvailSeats", bookedSeatList);
				bookedSeatList =Arrays.asList();
			}
			
			
			
			
			}
			else {
			System.out.println("same seat bookingis null");
		}		

		if ("MERSAL".equals(movieName)) {
			m.addAttribute("date",date);
			m.addAttribute("time", time);
			m.addAttribute("movieName", movieName);
			
		}

		if ("NAISEKER".equals(movieName)) {
			m.addAttribute("date",date);
			m.addAttribute("time", time);
			m.addAttribute("movieName", movieName);
		}

		if ("LEGENT".equals(movieName)) {
			m.addAttribute("date",date);
			m.addAttribute("time", time);
			m.addAttribute("movieName", movieName);
		}
		
		

		return "seatselection";
	}
	////
	
	//************************************************************************************importent
	
	@GetMapping("/Masila")
	@Transactional
	public String Selected_Seats(@RequestParam(name = "seat", required = false) String selectedSeats, Model model) {
		///TIME 01.53am// SUCCESS FULLY FECH SEATS
		
		//List<String> seat= selectedSeats;
		System.out.println(selectedSeats);
		System.out.println(selectedSeats.getClass());
		int rupee = 150;
		BDTLS.setSeatts(selectedSeats);
		//
		BDTLS.setDate(date);
		BDTLS.setEmail(bookingUserEmail);
		BDTLS.setName(bookingUserName);
		BDTLS.setMovie_Name(movieName);
		BDTLS.setTime(time);
		BDTLS.setMobile(mobileNumber);
		//
		BDTLS.setRupees(len(selectedSeats)* rupee);
		//
		//seat_booking_detailes DTL=new  seat_booking_detailes(bookingUserName,bookingUserEmail,selectedSeats,len(selectedSeats)* rupee,mobileNumber,time,date,movieName);
		Service.save(BDTLS);
		BDTLS=new seat_booking_detailes();
		
		//thymeleaf conf
		model.addAttribute("movieName", movieName);
		model.addAttribute("seats",selectedSeats);
		model.addAttribute("time", time);
		model.addAttribute("price",len(selectedSeats)* rupee );
		return "BookingSuccess" ;
		
	}

	
	private int len(String selectedSeats) {
		if (selectedSeats != null) {
			//splting
			String[] seatsArray = selectedSeats.split(",");
			int sizeOfseatArray=seatsArray.length;
			return sizeOfseatArray;
		}
		return 0;
	}
	
	@GetMapping("/home")
	public String home1() {
		return "home";		
	}
	

}
